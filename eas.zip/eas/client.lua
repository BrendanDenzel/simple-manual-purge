RegisterNetEvent("SendAlert")
AddEventHandler("SendAlert", function(msg, msg2)
    -- Send the NUI message to display the alert
    SendNUIMessage({
        type    = "alert",
        enable  = true,
        issuer  = msg,
        message = msg2,
        volume  = Config.EAS.Volume
    })

    -- Set a timer to revert the time back to the original after 5 minutes
    SetTimeout(300000, function()
        -- Reset the in-game time to its normal state
        NetworkOverrideClockTime(0, 0, 0)
    end)

    -- Set the in-game time to night (you can adjust the values based on your preference)
    NetworkOverrideClockTime(23, 0, 0)
end)
