Config = {}
Config.EAS = {}
Config.EAS.Volume = .5 --(0.2 = 20% Volume)