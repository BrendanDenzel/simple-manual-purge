Config = {}
Config.EAS = {}
Config.EAS.admins = 
{
    'steam:11000011cdaf055', -- Replace with your steam ID64 (Convert from HEX to DEC)
}
