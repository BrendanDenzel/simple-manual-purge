# eas-fivem
The Emergency Alert System in FiveM.

**INSTALL**
Download and unzip the file. Drag and drop the folder into your resources folder. The folder must be called eas. You may go into the config files and change what is necessary for your needs. You must add ensure eas or start eas based on the way your server is ran in your server config. Any questions ask in the thread.

**HOW TO USE**
Use the /purge command followed by whatever text for example PURGE!!! in your server.

**LICENSE**
YOU MAY DISTRIBUTE AS LONG AS CREDIT CAN STILL BE FOUND IN THIS README

**CREDITS:**
Denzel now know as Joseph S. in Phoenix Protocol FiveM Server


